package com.workshop.june8.bankingapi.service;

public interface LoanApi {

    public boolean hasCurrentDebts( String bsn);

}
